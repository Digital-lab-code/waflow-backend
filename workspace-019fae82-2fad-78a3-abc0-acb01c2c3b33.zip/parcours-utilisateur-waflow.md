# 🧭 Parcours Utilisateur — WaFlow

> Document compagnon des maquettes UI/UX · v1.0

---

## 👥 Personas cibles

| Persona | Profil | Besoin principal |
|---|---|---|
| **Leila** 🛍️ | E-commerçante (Tanger) | Répondre vite + campagnes promo |
| **Karim** 🏥 | Gérant de clinique | Rendez-vous + rappels automatiques |
| **Sofia** 📣 | Community manager (agence) | Gérer plusieurs clients/numéros |

---

## 🔄 Parcours 1 — Premier démarrage (Onboarding)

```
Téléchargement → Écran Bienvenue → Connexion WhatsApp Business (QR/Code)
     → Autorisations → Configuration profil → Tableau de bord ✅
```

| Étape | Écran | Action utilisateur | Système |
|---|---|---|---|
| 1 | Bienvenue | Lit la proposition de valeur | Affiche les 3 atouts clés |
| 2 | Connexion | Scanne le QR / saisit le code | Lie le numéro via API officielle |
| 3 | Profil | Nom, logo, secteur | Configure le chatbot par défaut |
| 4 | Dashboard | Découvre les stats vides | Suggère la 1ʳᵉ campagne |

**🎯 Objectif** : activer l'utilisateur en < 3 minutes (time-to-value).

---

## 🔄 Parcours 2 — Répondre à un client (Inbox + Chatbot)

```
Notification reçue → Inbox → Ouverture conversation → Réponse (auto ou manuelle)
```

| Étape | Écran | Action | Détail |
|---|---|---|---|
| 1 | Dashboard | Voit badge "7 non lues" | — |
| 2 | Inbox | Filtre "Bot" / "Non lues" | Tri intelligent |
| 3 | Conversation | Lit l'échange | Le bot a déjà répondu ✅ |
| 4 | Conversation | Reprend la main si besoin | Désactive le bot sur ce chat |

**🎯 Bénéfice** : 80 % des questions FAQ gérées sans intervention humaine.

---

## 🔄 Parcours 3 — Lancer une campagne (Broadcast opt-in)

> ⚠️ Uniquement vers des contacts **ayant consenti** (conformité API officielle).

```
Dashboard → Nouvelle campagne → Sélection audience → Rédaction → Envoyer / Programmer
```

| Étape | Écran | Action | Règles |
|---|---|---|---|
| 1 | Dashboard | Tape "Broadcast" | — |
| 2 | Campagne | Choisit un segment | Ex: "VIP Casablanca" (412) |
| 3 | Rédaction | Message + variables `{prénom}` | Anti-spam activé |
| 4 | Envoi | Immédiat ou programmé | Quota selon le plan |

**🎯 Objectif** : envoyer à N contacts en 1 action, sans risque de ban.

---

## 🔄 Parcours 4 — Programmer un message/statut

```
Programmation → + Nouveau → Type (msg/statut) → Date/heure → Récurrence → Actif
```

| Type | Exemple | Récurrence |
|---|---|---|
| Message promo | "Solde -30% ce week-end" | Quotidien 9h |
| Rappel RDV | "RDV demain 10h" | Lun-Ven |
| Statut 📸 | Photo produit du soir | Une fois |
| Anniversaire 🎂 | Message personnalisé | Annuel |

**🎯 Bénéfice** : communication planifiée, même hors-ligne.

---

## 🔄 Parcours 5 — Conversion Freemium → Premium 💰

```
Usage limite atteint → Écran "Passer Premium" → Choix du plan → Paiement → Déblocage
```

| Déclencheur | Message affiché | Conversion vers |
|---|---|---|
| > 100 contacts | "Passez Pro pour 1 000 contacts" | Pro |
| Chatbot désiré | "Activez l'IA GPT-4 avec Pro" | Pro |
| > 1 000 contacts | "Business pour 10 000 + multi-numéros" | Business |
| Besoin API | "Business débloque l'API + marque blanche" | Business |

**🎯 Objectif** : freemium fluide, paywall déclenché par la valeur, pas par la frustration.

---

## ✅ Principes UX appliqués

1. **Time-to-value < 3 min** — onboarding express.
2. **Anti-friction** — moins de 3 taps pour les actions clés.
3. **Transparence** — le bot signale toujours ses messages.
4. **Conformité visible** — rappels opt-in, pas de fonction illégale masquée.
5. **Mobile-first** — pensé pouce + une main, nav en bas.

---

## 📌 Prochaine étape suggérée
Transformer ces maquettes en **prototype interactif** (Flutter) ou un **prototype cliquable Figma**.
