# 📋 Cahier des Charges — Plateforme de Gestion WhatsApp

> **Version** : 1.0 · **Date** : 2026-07-29 · **Statut** : Proposition initiale

---

## 1. 🎯 Vision & Positionnement

Créer une plateforme SaaS (web + mobile) qui permet aux **PME, e-commerçants, community managers et indépendants** de centraliser, automatiser et monétiser leur communication WhatsApp — de façon **légale, durable et sans risque de bannissement**.

### Positionnement
| | Notre plateforme | Outils pirates | WhatsApp direct |
|---|---|---|---|
| Légal | ✅ | ❌ Bannissement | ✅ |
| Automatisation | ✅ Avancée | ✅ Mais risquée | ❌ Manuelle |
| Multi-agents | ✅ | Variable | ❌ |
| Monétisable (freemium) | ✅ | Fragile | ❌ |

**Naming suggéré** : *WaFlow*, *NexaChat*, *ChatPilot* (à réserver).

---

## 2. ⚙️ Réalité technique WhatsApp (à connaître par cœur)

Deux voies existent. **Une seule est viable à long terme.**

### ✅ Voie officielle : WhatsApp Business Platform (Cloud API de Meta)
- Gratuit à l'accès (depuis 2022).
- Demande : compte **Meta Business** + numéro **WhatsApp Business** dédié.
- **Tarification** : au nombre de *conversations* (les 1 000 premières conversations/service sont gratuites/mois), puis ~0,00 $ à 0,08 $/conversation selon le pays et la catégorie.
- Permet : envoi/réception, médias, templates, chatbots, multi-agents, webhooks, **programmation** (via votre propre file d'attente).
- Limites : ~1 000 conversations initiées par l'entreprise / 24 h par numéro (plafond progressif), templates à valider, **fenêtre de 24 h** pour répondre librement.

### ❌ Voie non officielle (wa-web.js, Baileys, automatisation Web)
- Techniquement « tout est possible », mais :
- 🔴 **Contre les CGU de WhatsApp** → bannissement définitif du numéro.
- 🔴 Détection anti-automatisation de plus en plus performante.
- 🔴 Exposition juridique de l'éditeur (vous).

> **Décision d'architecture** : le cœur de la plateforme utilise l'**API officielle Cloud de Meta**. C'est ce qui rend le produit durable et monétisable.

---

## 3. 🧩 Fonctionnalités (par paliers)

### 🆓 Tier FREE — Acquisition
- 1 numéro WhatsApp Business connecté
- Boîte de réception unifiée (1 agent)
- Réponses automatiques simples (règles mot-clé)
- 50 messages programmés / mois
- Gestion de 100 contacts
- Statistiques de base

### ⭐ Tier PRO (Premium) — PME & indépendants
- Tout FREE +
- Chatbot IA (connecté à un LLM : GPT / Claude)
- Messages programmés illimités + calendrier
- Campagnes vers listes **opt-in** (jusqu'à 1 000 contacts)
- 3 agents / collaborateurs
- Modèles de messages (templates) illimités
- Étiquettes & segments de contacts
- Import de contacts (CSV) + segmentation avancée
- Statistiques avancées (taux d'ouverture, clics)
- **Rappels automatiques & séquences (drip campaigns)**

### 🏢 Tier BUSINESS — Agences & e-commerce
- Tout PRO +
- Nombres illimités d'agents
- Multi-numéros WhatsApp
- Campagnes jusqu'à 10 000 contacts (opt-in)
- Intégrations : Shopify, WooCommerce, Zapier, Google Sheets
- API publique (pour développeurs)
- Marque blanche / sous-comptes clients
- Support prioritaire + gestionnaire de compte
- **Catalogue produits & paiement in-chat**

### 🚫 Fonctionnalités explicitement NON incluses (et pourquoi)
- **Scraper les contacts des groupes** → illégal + ban.
- **« Booster » les statuts** → pas de fonction officielle + ban.
- **Spam vers numéros sans consentement** → ban immédiat.

> 💡 *Alternative légale au scraping* : outil de **génération de leads opt-in** (QR codes, formulaires web, liens wa.me) pour faire grandir les listes *volontairement*.

---

## 4. 🏗️ Architecture technique

```
┌─────────────────────────────────────────────────────────┐
│                    CLIENTS (utilisateurs)                │
│   App Mobile (Flutter)   ·   Web App (React/Next.js)     │
└───────────────┬─────────────────────────┬───────────────┘
                │   HTTPS / WebSocket     │
                ▼                         ▼
┌─────────────────────────────────────────────────────────┐
│                     API GATEWAY                          │
│          (Auth, rate-limit, routing — Node.js)           │
└───────┬───────────────┬──────────────────┬──────────────┘
        ▼               ▼                  ▼
┌──────────────┐ ┌──────────────┐ ┌─────────────────────┐
│  Messagerie  │ │  Planificateur│ │   Chatbot / IA      │
│  (envoi/récep│ │  (file BullMQ │ │   (LLM + règles)    │
│   webhooks)  │ │   + cron)     │ │                     │
└──────┬───────┘ └──────────────┘ └──────────┬──────────┘
       │                                      │
       ▼                                      ▼
┌─────────────────────────┐        ┌─────────────────────┐
│  WhatsApp Cloud API     │        │   CRM & Contacts    │
│  (Meta — officielle)    │        │   (PostgreSQL)      │
└─────────────────────────┘        └─────────────────────┘
        │
        ▼
┌─────────────────────────┐        ┌─────────────────────┐
│  Webhooks Meta          │◄──────►│  Paiement (Stripe/  │
│  (réception messages)   │        │  Paystack/CMI)      │
└─────────────────────────┘        └─────────────────────┘
```

### Composants clés
| Composant | Techno recommandée | Rôle |
|---|---|---|
| App mobile | **Flutter** (iOS + Android) | Interface utilisateur cross-platform |
| Web app | **Next.js (React)** | Console d'administration web |
| Backend API | **Node.js + NestJS** | Logique métier, auth, REST/GraphQL |
| Planificateur | **BullMQ + Redis** | Files d'attente, programmation, retry |
| Base de données | **PostgreSQL** | Contacts, messages, comptes |
| Cache/temps réel | **Redis + WebSockets** | Inbox live, notifications |
| Chatbot IA | **OpenAI / Anthropic API** | Réponses automatiques intelligentes |
| Stockage médias | **S3 / Cloudinary** | Images, PDF, audios |
| Paiement | **Stripe / Paystack / CMI** | Abonnements freemium |
| Hébergement | **Vercel (front) + Render/Railway/AWS (back)** | Déploiement |

---

## 5. 💰 Modèle économique (Freemium)

| Tier | Prix indicatif | Cible |
|---|---|---|
| **Free** | 0 $ | Découverte, acquisition |
| **Pro** | ~19–29 $ / mois | PME, indépendants |
| **Business** | ~59–99 $ / mois | Agences, e-commerce |
| **Enterprise** | Sur devis | Grands comptes |

### Coûts à anticiper (variable)
- **Coût API WhatsApp** : facturé par Meta, à répercuter ou inclure (fair-use).
- **Coût IA** : par token (GPT/Claude) — prévoir un quota par tier.
- **Hébergement** : ~50–200 $/mois au début.

> 🔑 *Leviers de revenus Premium* : quotas de contacts, campagnes, agents IA, multi-numéros, API, marque blanche.

---

## 6. 🗺️ Roadmap de développement

### Phase 1 — MVP (8–12 semaines) 🚀
- Connexion au WhatsApp Cloud API officiel
- Inbox unifiée + envoi/réception de messages
- Authentification & comptes utilisateurs
- Programmation simple de messages
- Tier Free + Pro (paiement Stripe)

### Phase 2 — Automatisation (4–6 semaines) 🤖
- Chatbot IA (LLM)
- Réponses automatiques + règles
- Séquences / drip campaigns
- Import CSV + segmentation

### Phase 3 — Croissance (4–6 semaines) 📈
- Multi-agents & rôles
- Campagnes opt-in + analytics
- Intégrations e-commerce (Shopify/WooCommerce)
- App mobile (Flutter)

### Phase 4 — Business & scale (continue) 🏢
- Multi-numéros, marque blanche, API publique
- Catalogue & paiement in-chat
- Optimisations, sécurité, conformité RGPD

---

## 7. ⚠️ Risques & Mitigation

| Risque | Impact | Mitigation |
|---|---|---|
| Bannissement (si non-officiel) | 🔴 Critique | → **API officielle uniquement** |
| Non-respect RGPD / données | 🔴 Élevé | Hébergement conforme, consentement opt-in documenté |
| Coûts API imprévus | 🟡 Moyen | Quotas par tier, monitoring, alertes |
| Concurrence (Wati, respond.io) | 🟡 Moyen | Spécialisation locale (Maghreb, paiement CMI, AR/FR) |
| Validation templates Meta lente | 🟡 Moyen | Bibliothèque de templates pré-validés |

---

## 8. 🔍 Concurrents de référence (benchmark)
- **Wati**, **respond.io**, **Zoko**, **360dialog**, **Twilio**, **Trengo**
- *Étudier leur pricing et fonctionnalités pour se différencier.*

### Pistes de différenciation (votre avantage)
1. **Focus Maghreb / Afrique** : paiement CMI, Paystack, support AR/FR.
2. **Onboarding simplifié** pour non-techniques.
3. **Tarifs accessibles** aux PME locales.
4. **Templates pré-conçus** par secteur (restaurant, e-shop, clinique…).

---

## 9. ✅ Prochaines étapes
1. ✅ Valider ce cahier des charges
2. 🔧 Créer un compte **Meta Business** + app Cloud API
3. 🎨 Maquettes UI/UX (Figma)
4. 💻 Démarrer le **MVP** (Phase 1)
5. 🧪 Tests avec 5–10 beta-testeurs
6. 🚀 Lancement Free + Pro

---

*Document vivant — à itérer selon vos retours.*
