# 🚀 Guide de lancement & test — WaFlow

> Objectif : lancer la plateforme et **tester TOUTES les fonctionnalités premium sans payer**, en tant que concepteur.

---

## 0. Prérequis (à installer une fois)

| Outil | Pourquoi | Lien |
|---|---|---|
| **Node.js 18+** | Faire tourner le backend | https://nodejs.org |
| **Flutter 3.10+** | Lancer l'app mobile | https://flutter.dev (puis `flutter doctor`) |
| Un téléphone ou un **émulateur Android** | Voir l'app | (Android Studio) |

Vérifiez :
```bash
node -v        # doit afficher v18 ou +
flutter doctor # tout doit être vert (au moins Android)
```

---

## 1. 🟢 Lancer le backend (le « moteur »)

```bash
cd waflow-backend
npm install                 # installe les dépendances
cp .env.example .env        # crée la config (mode DÉMO par défaut)
npm run dev                 # démarre le serveur
```

✅ Vous devez voir la bannière :
```
║   WaFlow Backend — API WhatsApp officielle ║
▶  http://localhost:3000
▶  Mode : DRY-RUN (simulation, sans Meta)
⏱️  Planificateur démarré…
```

> **C'est tout pour le backend.** Il est en *mode démo* :
> - les messages WhatsApp sont **simulés** (pas besoin de compte Meta)
> - les paiements sont **simulés** (pas besoin de Stripe)
> - le chatbot répond par **mots-clés** (pas besoin de clé IA)

Vérifiez dans un autre terminal :
```bash
curl http://localhost:3000/api/health
```

---

## 2. 📱 Lancer l'app mobile (Flutter)

```bash
cd waflow_app
flutter create --org com.waflow .   # génère les dossiers android/ios
flutter pub get                     # installe les dépendances
flutter run                         # lance sur l'émulateur/téléphone
```

### ⚠️ Si vous testez sur Android (obligatoire pour le HTTP local)
Ouvrez `android/app/src/main/AndroidManifest.xml` et modifiez la balise `<application>` :
```xml
<application
    android:usesCleartextTraffic="true"   <!-- ajoutez cette ligne -->
    ...>
```
Et ajoutez avant `<application>` :
```xml
<uses-permission android:name="android.permission.INTERNET"/>
```

### Brancher l'app au backend
L'URL est dans `waflow_app/lib/config.dart` :
- Émulateur Android → `http://10.0.2.2:3000` *(déjà réglé par défaut)*
- Simulateur iOS / Mac → `http://localhost:3000`
- Téléphone réel (même Wi-Fi) → `http://IP_DE_VOTRE_PC:3000`

✅ L'app s'ouvre sur l'écran de bienvenue → **« Connecter mon WhatsApp »** → tableau de bord.
Le tableau de bord affiche les vraies stats (si le backend tourne) ou une bannière « hors-ligne » sinon.

---

## 3. ⭐ Tester les fonctionnalités PREMIUM sans payer

C'est le cœur de votre question. **En mode démo, vous activez n'importe quel plan instantanément et gratuitement.**

### Option A — Depuis l'app (le plus simple)
1. Tableau de bord → action rapide **⭐ Premium** (ou Réglages → Abonnement)
2. Écran des 3 plans → tapez **« Choisir Pro → »**
3. Message : **🎉 Plan Pro activé !** → c'est fait, sans aucune carte bancaire.
4. Testez une campagne de 200 destinataires → ça passe (Pro autorise jusqu'à 1000).
5. Pour revenir Free : bouton **« Annuler l'abonnement »** en bas.

### Option B — Depuis le terminal (pour bien comprendre)
Chaque « compte » est identifié par l'en-tête `x-account-id`. Le compte de l'app est `demo_account`.

```bash
# Voir le plan actuel du compte de l'app
curl http://localhost:3000/api/billing/subscription -H "x-account-id: demo_account"

# Activer Pro gratuitement
curl -X POST http://localhost:3000/api/billing/mock/complete \
  -H "Content-Type: application/json" -H "x-account-id: demo_account" \
  -d '{"planId":"pro"}'

# Activer Business gratuitement
curl -X POST http://localhost:3000/api/billing/mock/complete \
  -H "Content-Type: application/json" -H "x-account-id: demo_account" \
  -d '{"planId":"business"}'

# Revenir à Free
curl -X POST http://localhost:3000/api/billing/cancel -H "x-account-id: demo_account"
```

💡 **Astuce** : changez `x-account-id` (ex. `client1`, `client2`) pour simuler plusieurs utilisateurs, chacun avec son propre plan. Pour cela dans l'app, modifiez `accountId` dans `waflow_app/lib/config.dart`.

### Tester la différence de quotas
| Action | En Free | En Pro |
|---|---|---|
| Campagne de 200 contacts | ❌ bloqué (limite 50) | ✅ autorisé (jusqu'à 1000) |
| Chatbot IA | mots-clés | mots-clés (+ IA si clé) |

Exemple en Free → doit être refusé (HTTP 402) :
```bash
curl -X POST http://localhost:3000/api/campaigns \
  -H "Content-Type: application/json" -H "x-account-id: demo_account" \
  -d '{"name":"test","to":["+212612345001","+212612345002"]}'
```

---

## 4. 🧪 Tester chaque fonctionnalité

| Fonctionnalité | Comment la tester |
|---|---|
| **Envoi de message** | App : ouvrez une conversation → tapez → ➤. (simulation console backend) |
| **Message programmé** | App : onglet Campagnes → ➕ → date/heure future. Ou il part seul si échéance passée. |
| **Auto-réponse (chatbot)** | Voir §5 ci-dessous |
| **Campagnes** | App : onglet Campagnes → ➕ ; ou curl `/api/campaigns` |
| **Quotas freemium** | Voir §3 (Free vs Pro) |
| **Statistiques** | App : tableau de bord (stats réelles via `/api/health`) |

---

## 5. 🤖 Tester le chatbot (message entrant → réponse auto)

Simulez un message reçu d'un client (le backend répond tout seul) :

```bash
curl -X POST http://localhost:3000/api/webhook \
  -H "Content-Type: application/json" \
  -d '{"entry":[{"changes":[{"value":{"contacts":[{"profile":{"name":"Leila"}}],"messages":[{"from":"212612345678","text":{"body":"Bonjour, quels sont vos horaires ?"}}]}}]}]}'
```
→ Dans la console backend vous verrez : `🤖 Réponse (keywords) → 212612345678 : "…ouverts de 9h à 19h…"`

**Pour une vraie IA (GPT/Claude) gratuitement**, vous pouvez utiliser une API avec offre gratuite, ex. **Groq** (compatible OpenAI) :
```bash
# dans waflow-backend/.env
AI_PROVIDER=openai
AI_API_KEY=gsk_votre_clef_groq              # création gratuite sur console.groq.com
AI_MODEL=llama-3.3-70b-versatile
AI_BASE_URL=https://api.groq.com/openai/v1
```
Relancez le backend → le bot répondra avec une vraie IA, avec mémoire de conversation. *(Le repli mots-clés reste actif sans clé.)*

---

## 6. 🧹 Gérer les données de test

Tout est stocké dans `waflow-backend/data/db.json`. Pour repartir de zéro :
```bash
# arrêtez le backend (Ctrl+C), puis :
rm waflow-backend/data/db.json
npm run dev    # repart à neuf (compte Free, aucune campagne…)
```

---

## 7. 🔴 Passer en « réel » plus tard (quand vous voudrez)

Quand vous serez prêt à facturer de vrais clients, ajoutez simplement les clés dans `waflow-backend/.env` et le mode démo se désactive tout seul :

| Variable | Effet | Où l'obtenir |
|---|---|---|
| `DRY_RUN=false` + clés `WHATSAPP_*` | Vrais messages WhatsApp | developers.facebook.com |
| `AI_API_KEY` (+ `AI_PROVIDER`) | Vrai chatbot IA | OpenAI / Anthropic / Groq |
| `STRIPE_SECRET_KEY` + `STRIPE_PRICE_*` | Vrais paiements | dashboard.stripe.com |

> Aucun code à réécrire — juste des variables d'environnement.

---

## ✅ En résumé (le chemin le plus court)
```bash
# Terminal 1
cd waflow-backend && npm install && cp .env.example .env && npm run dev

# Terminal 2
cd waflow_app && flutter create --org com.waflow . && flutter pub get && flutter run
```
Puis dans l'app : **Premium → Choisir Pro** → toutes les fonctions premium débloquées, **sans payer**. 🎉
