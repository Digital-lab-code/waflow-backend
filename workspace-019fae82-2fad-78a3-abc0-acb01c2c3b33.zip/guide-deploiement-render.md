# 🌐 Guide de déploiement — WaFlow sur Render (gratuit, lien permanent)

> Objectif : obtenir une adresse publique **définitive** du type `https://waflow-backend.onrender.com`, accessible depuis n'importe quel téléphone, qui ne s'éteint jamais.

Le backend est **déjà prêt** pour Render (fichiers `render.yaml` et `.gitignore` ajoutés).

---

## 📋 Ce qu'il vous faut
1. Un compte **GitHub** gratuit → https://github.com/signup
2. Un compte **Render** gratuit → https://render.com (inscription avec votre compte GitHub)
3. Les fichiers du dossier **`waflow-backend`** (que vous avez déjà)

---

## ÉTAPE 1 — Mettre le code sur GitHub

1. Sur GitHub, cliquez **➕ → New repository**
2. Nom : `waflow-backend` · **Public** · **Ne pas** cocher « Add README » → **Create repository**
3. Sur la page qui s'ouvre, cliquez **« uploading an existing file »** (lien « Upload files »)
4. **Glissez-déposez TOUS les fichiers** du dossier `waflow-backend` (y compris le sous-dossier `src/`, `tests/`, et `render.yaml`, `package.json`, `.env.example`)
   - ⚠️ **Ne pas** glisser le dossier `node_modules` (pas nécessaire, ignoré)
5. En bas, cliquez **Commit changes**

✅ Votre code est en ligne sur GitHub.

---

## ÉTAPE 2 — Déployer sur Render

1. Sur **https://render.com**, cliquez **Sign in with GitHub**
2. Cliquez **New +** → **Blueprint**
3. Sélectionnez votre dépôt **`waflow-backend`** → **Apply**
4. Render détecte le fichier `render.yaml` et configure tout seul :
   - Type : Web Service (Node.js)
   - Build : `npm install`
   - Start : `npm start`
   - Vérif santé : `/api/health`
5. Cliquez **Apply / Create**
6. Patientez **2 à 4 minutes** (build + démarrage)
7. En haut, Render vous donne votre **URL publique** :
   ```
   https://waflow-backend.onrender.com     ← votre lien définitif ! 🎉
   ```

---

## ÉTAPE 3 — Vérifier que ça marche

Ouvrez ces liens dans votre navigateur (remplacez par VOTRE URL) :

| Lien | Résultat attendu |
|---|---|
| `https://waflow-backend.onrender.com/api/health` | `{"status":"ok","mode":"DRY-RUN (simulation)"…}` |
| `https://waflow-backend.onrender.com/api/billing/plans` | Les 3 plans Free/Pro/Business |
| `https://waflow-backend.onrender.com/api/billing/subscription` | Compte démo en Free |

✅ Si vous voyez le JSON → **c'est en ligne !**

---

## ÉTAPE 4 — Tester le premium (gratuit) en ligne

Dans un terminal, avec `VOTRE_URL` :

```bash
VOTRE_URL=https://waflow-backend.onrender.com

# Activer Pro gratuitement
curl -X POST $VOTRE_URL/api/billing/mock/complete \
  -H "Content-Type: application/json" -H "x-account-id: demo_account" \
  -d '{"planId":"pro"}'

# Vérifier
curl $VOTRE_URL/api/billing/subscription -H "x-account-id: demo_account"
# → "plan":"pro"
```

---

## ÉTAPE 5 — Brancher l'app mobile au site en ligne

Dans `waflow_app/lib/config.dart`, changez l'URL :
```dart
static const String baseUrl = 'https://waflow-backend.onrender.com';
```
Recompilez l'app → elle parle maintenant au site en ligne. ✅

---

## ⚠️ À savoir (Render gratuit)

| Point | Détail |
|---|---|
| 🌙 **Mise en veille** | Le service gratuit s'endort après 15 min d'inactivité. Le 1er clic met ~50 s à « réveiller » le serveur (soyez patient). |
| 🧹 **Données éphémères** | Les données de démo (`data/db.json`) sont **réinitialisées** à chaque redéploiement. Normal pour tester. (En production : ajouter une base PostgreSQL.) |
| 🔄 **Re-déploiement auto** | Chaque modification sur GitHub → Render redéploie automatiquement. |

---

## 🚀 Plus tard : passer en « réel »
Dans Render → votre service → **Environment** → ajoutez les variables :
- `DRY_RUN` = `false` + `WHATSAPP_TOKEN`, `PHONE_NUMBER_ID` (vrais messages WhatsApp)
- `AI_API_KEY`, `AI_MODEL` (vrai chatbot)
- `STRIPE_SECRET_KEY`, `STRIPE_PRICE_PRO`… (vrais paiements)

> Configurez le webhook WhatsApp sur `https://waflow-backend.onrender.com/api/webhook`.

---

## 🆘 En cas de problème
- **Build échoue** → vérifiez que `package.json` et le dossier `src/` sont bien sur GitHub.
- **« Application error »** → Render → service → onglet **Logs** pour voir l'erreur.
- **50 s d'attente** → normal (sortie de veille), réessayez.

*Une fois déployé, envoyez-moi votre URL Render et je la testerai avec vous !* 🚀
